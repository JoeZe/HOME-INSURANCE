1. I use Oracle 11 xe version.
2. I use Tomcat 8.0 or 8.5 version
